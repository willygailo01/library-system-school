-- =============================================
-- Library Management System - Database Setup
-- =============================================

CREATE DATABASE IF NOT EXISTS library_system;
USE library_system;

-- =============================================
-- Users Table
-- =============================================
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Books Table
-- =============================================
CREATE TABLE IF NOT EXISTS books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(160) NOT NULL,
  isbn VARCHAR(40) DEFAULT NULL,
  category VARCHAR(120) DEFAULT NULL,
  copies_total INT NOT NULL DEFAULT 1,
  copies_available INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Borrows Table
-- =============================================
CREATE TABLE IF NOT EXISTS borrows (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  borrowed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  due_at DATETIME NOT NULL,
  returned_at DATETIME DEFAULT NULL,
  status ENUM('borrowed', 'returned') NOT NULL DEFAULT 'borrowed',
  CONSTRAINT fk_borrows_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_borrows_book FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
  INDEX idx_borrows_status (status),
  INDEX idx_borrows_due (due_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Reservations Table
-- =============================================
CREATE TABLE IF NOT EXISTS reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  book_id INT NOT NULL,
  reserved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('active', 'cancelled', 'fulfilled') NOT NULL DEFAULT 'active',
  fulfilled_at DATETIME DEFAULT NULL,
  cancelled_at DATETIME DEFAULT NULL,
  CONSTRAINT fk_reservations_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_reservations_book FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
  INDEX idx_reservations_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =============================================
-- Default Admin Account
-- Password: password
-- =============================================
INSERT INTO users (full_name, email, password_hash, role)
VALUES ('System Admin', 'admin@library.com', '$2y$12$pr29RbnY/jImTRPwZht8I.xcrk8AZ0Fa80lGusX7gkmljk3SrDfky', 'admin')
ON DUPLICATE KEY UPDATE email = email;

-- =============================================
-- Sample Books (for testing)
-- =============================================
INSERT INTO books (title, author, isbn, category, copies_total, copies_available) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', '978-0743273565', 'Fiction', 5, 5),
('To Kill a Mockingbird', 'Harper Lee', '978-0446310789', 'Fiction', 3, 3),
('1984', 'George Orwell', '978-0451524935', 'Dystopian', 4, 4),
('Pride and Prejudice', 'Jane Austen', '978-0141439518', 'Romance', 3, 3),
('The Catcher in the Rye', 'J.D. Salinger', '978-0316769488', 'Fiction', 2, 2),
('Harry Potter and the Sorcerer''s Stone', 'J.K. Rowling', '978-0590353427', 'Fantasy', 5, 5),
('The Hobbit', 'J.R.R. Tolkien', '978-0547928227', 'Fantasy', 3, 3),
('The Da Vinci Code', 'Dan Brown', '978-0307474278', 'Mystery', 4, 4),
('The Alchemist', 'Paulo Coelho', '978-0062315007', 'Fiction', 3, 3),
('Animal Farm', 'George Orwell', '978-0452284244', 'Political', 2, 2),
('Brave New World', 'Aldous Huxley', '978-0060850524', 'Dystopian', 3, 3),
('The Lord of the Rings', 'J.R.R. Tolkien', '978-0618640157', 'Fantasy', 4, 4),
('Crime and Punishment', 'Fyodor Dostoevsky', '978-0143058144', 'Classic', 2, 2),
('The Kite Runner', 'Khaled Hosseini', '978-1594631931', 'Fiction', 3, 3),
('Charlotte''s Web', 'E.B. White', '978-0061124952', 'Children', 5, 5)
ON DUPLICATE KEY UPDATE title = title;
