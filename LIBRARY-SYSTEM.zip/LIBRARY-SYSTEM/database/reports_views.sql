-- =============================================
-- Library Management System - Reports Views
-- =============================================
USE library_system;

-- =============================================
-- View: Active Borrows Report
-- Shows all books currently borrowed
-- =============================================
DROP VIEW IF EXISTS view_borrow_report;

CREATE VIEW view_borrow_report AS
SELECT
  b.id AS borrow_id,
  u.id AS user_id,
  u.full_name AS user_name,
  u.email AS user_email,
  bk.id AS book_id,
  bk.title AS book_title,
  bk.author AS book_author,
  b.borrowed_at,
  b.due_at,
  b.status
FROM borrows b
JOIN users u ON u.id = b.user_id
JOIN books bk ON bk.id = b.book_id
WHERE b.status = 'borrowed';

-- =============================================
-- View: Return Report
-- Shows all books that have been returned
-- =============================================
DROP VIEW IF EXISTS view_return_report;

CREATE VIEW view_return_report AS
SELECT
  b.id AS borrow_id,
  u.id AS user_id,
  u.full_name AS user_name,
  u.email AS user_email,
  bk.id AS book_id,
  bk.title AS book_title,
  bk.author AS book_author,
  b.borrowed_at,
  b.due_at,
  b.returned_at
FROM borrows b
JOIN users u ON u.id = b.user_id
JOIN books bk ON bk.id = b.book_id
WHERE b.status = 'returned';

-- =============================================
-- View: Reservation Report
-- Shows all reservations (active, fulfilled, cancelled)
-- =============================================
DROP VIEW IF EXISTS view_reserve_report;

CREATE VIEW view_reserve_report AS
SELECT
  r.id AS reservation_id,
  u.id AS user_id,
  u.full_name AS user_name,
  u.email AS user_email,
  bk.id AS book_id,
  bk.title AS book_title,
  bk.author AS book_author,
  r.reserved_at,
  r.status,
  r.fulfilled_at,
  r.cancelled_at
FROM reservations r
JOIN users u ON u.id = r.user_id
JOIN books bk ON bk.id = r.book_id;

-- =============================================
-- View: Full Activity Report
-- Shows all borrow and reservation activity
-- =============================================
DROP VIEW IF EXISTS view_full_report;

CREATE VIEW view_full_report AS
SELECT
  b.id AS record_id,
  'borrow' AS record_type,
  u.id AS user_id,
  u.full_name AS user_name,
  u.email AS user_email,
  bk.id AS book_id,
  bk.title AS book_title,
  bk.author AS book_author,
  b.borrowed_at AS record_date,
  b.status
FROM borrows b
JOIN users u ON u.id = b.user_id
JOIN books bk ON bk.id = b.book_id

UNION ALL

SELECT
  r.id AS record_id,
  'reservation' AS record_type,
  u.id AS user_id,
  u.full_name AS user_name,
  u.email AS user_email,
  bk.id AS book_id,
  bk.title AS book_title,
  bk.author AS book_author,
  r.reserved_at AS record_date,
  r.status
FROM reservations r
JOIN users u ON u.id = r.user_id
JOIN books bk ON bk.id = r.book_id;
