<?php
/**
 * Database Setup Script
 * Run this file to set up the database
 * 
 * Usage: php setup.php
 * Or open in browser: http://localhost/library-system/setup.php
 */

$env = [
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'library_system',
  'DB_USER' => 'root',
  'DB_PASS' => '',
  'DB_CHARSET' => 'utf8mb4'
];

foreach ($env as $key => $default) {
  if (!defined($key)) {
    define($key, getenv($key) ?: $default);
  }
}

echo "<pre>";
echo "========================================\n";
echo "Library System - Database Setup\n";
echo "========================================\n\n";

try {
    // Connect without database
    $pdo = new PDO('mysql:host=' . DB_HOST, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Drop and create database
    $pdo->exec('DROP DATABASE IF EXISTS ' . DB_NAME);
    $pdo->exec('CREATE DATABASE ' . DB_NAME);
    $pdo->exec('USE ' . DB_NAME);
    echo "✓ Database created\n\n";

    // Create users table
    $pdo->exec("
        CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(120) NOT NULL,
            email VARCHAR(160) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "✓ Users table created\n";

    // Create books table
    $pdo->exec("
        CREATE TABLE books (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            author VARCHAR(160) NOT NULL,
            isbn VARCHAR(40) DEFAULT NULL,
            category VARCHAR(120) DEFAULT NULL,
            copies_total INT NOT NULL DEFAULT 1,
            copies_available INT NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "✓ Books table created\n";

    // Create borrows table
    $pdo->exec("
        CREATE TABLE borrows (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            book_id INT NOT NULL,
            borrowed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            due_at DATETIME NOT NULL,
            returned_at DATETIME DEFAULT NULL,
            status ENUM('borrowed', 'returned') NOT NULL DEFAULT 'borrowed',
            CONSTRAINT fk_borrows_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_borrows_book FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
            INDEX idx_borrows_status (status),
            INDEX idx_borrows_due (due_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "✓ Borrows table created\n";

    // Create reservations table
    $pdo->exec("
        CREATE TABLE reservations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            book_id INT NOT NULL,
            reserved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            status ENUM('active', 'cancelled', 'fulfilled') NOT NULL DEFAULT 'active',
            fulfilled_at DATETIME DEFAULT NULL,
            cancelled_at DATETIME DEFAULT NULL,
            CONSTRAINT fk_reservations_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_reservations_book FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
            INDEX idx_reservations_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    echo "✓ Reservations table created\n";

    // Create views
    $pdo->exec("
        CREATE OR REPLACE VIEW view_borrow_report AS
        SELECT b.id AS borrow_id, u.id AS user_id, u.full_name AS user_name, u.email AS user_email,
        bk.id AS book_id, bk.title AS book_title, bk.author AS book_author,
        b.borrowed_at, b.due_at, b.status
        FROM borrows b
        JOIN users u ON u.id = b.user_id
        JOIN books bk ON bk.id = b.book_id
        WHERE b.status = 'borrowed'
    ");
    echo "✓ view_borrow_report created\n";

    $pdo->exec("
        CREATE OR REPLACE VIEW view_return_report AS
        SELECT b.id AS borrow_id, u.id AS user_id, u.full_name AS user_name, u.email AS user_email,
        bk.id AS book_id, bk.title AS book_title, bk.author AS book_author,
        b.borrowed_at, b.due_at, b.returned_at
        FROM borrows b
        JOIN users u ON u.id = b.user_id
        JOIN books bk ON bk.id = b.book_id
        WHERE b.status = 'returned'
    ");
    echo "✓ view_return_report created\n";

    $pdo->exec("
        CREATE OR REPLACE VIEW view_reserve_report AS
        SELECT r.id AS reservation_id, u.id AS user_id, u.full_name AS user_name, u.email AS user_email,
        bk.id AS book_id, bk.title AS book_title, bk.author AS book_author,
        r.reserved_at, r.status, r.fulfilled_at, r.cancelled_at
        FROM reservations r
        JOIN users u ON u.id = r.user_id
        JOIN books bk ON bk.id = r.book_id
    ");
    echo "✓ view_reserve_report created\n";

    $pdo->exec("
        CREATE OR REPLACE VIEW view_full_report AS
        SELECT b.id AS record_id, 'borrow' AS record_type, u.id AS user_id, u.full_name AS user_name, 
        u.email AS user_email, bk.id AS book_id, bk.title AS book_title, bk.author AS book_author,
        b.borrowed_at AS record_date, b.status
        FROM borrows b
        JOIN users u ON u.id = b.user_id
        JOIN books bk ON bk.id = b.book_id
        UNION ALL
        SELECT r.id AS record_id, 'reservation' AS record_type, u.id AS user_id, u.full_name AS user_name,
        u.email AS user_email, bk.id AS book_id, bk.title AS book_title, bk.author AS book_author,
        r.reserved_at AS record_date, r.status
        FROM reservations r
        JOIN users u ON u.id = r.user_id
        JOIN books bk ON bk.id = r.book_id
    ");
    echo "✓ view_full_report created\n";

    // Insert admin user
    $adminPassword = password_hash('password', PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)");
    $stmt->execute(['System Admin', 'admin@library.com', $adminPassword, 'admin']);
    echo "✓ Admin user created\n";

    // Insert sample books
    $books = [
        ['The Great Gatsby', 'F. Scott Fitzgerald', '978-0743273565', 'Fiction', 5],
        ['To Kill a Mockingbird', 'Harper Lee', '978-0446310789', 'Fiction', 3],
        ['1984', 'George Orwell', '978-0451524935', 'Dystopian', 4],
        ['Pride and Prejudice', 'Jane Austen', '978-0141439518', 'Romance', 3],
        ['The Catcher in the Rye', 'J.D. Salinger', '978-0316769488', 'Fiction', 2],
        ['Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling', '978-0590353427', 'Fantasy', 5],
        ['The Hobbit', 'J.R.R. Tolkien', '978-0547928227', 'Fantasy', 3],
        ['The Da Vinci Code', 'Dan Brown', '978-0307474278', 'Mystery', 4],
        ['The Alchemist', 'Paulo Coelho', '978-0062315007', 'Fiction', 3],
        ['Animal Farm', 'George Orwell', '978-0452284244', 'Political', 2],
    ];

    $stmt = $pdo->prepare("INSERT INTO books (title, author, isbn, category, copies_total, copies_available) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($books as $book) {
        $stmt->execute([$book[0], $book[1], $book[2], $book[3], $book[4], $book[4]]);
    }
    echo "✓ 10 Sample books added\n";

    echo "\n========================================\n";
    echo "✅ Setup Complete!\n";
    echo "========================================\n";
    echo "Login credentials:\n";
    echo "  Email: admin@library.com\n";
    echo "  Password: password\n";
    echo "========================================\n";
    echo "\n<a href='auth/login.php'>Go to Login</a>\n";

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}

echo "</pre>";
