<?php
require_once __DIR__ . '/../includes/user_or_admin.php';

$page_title = 'Reserve Book';
$is_admin = false;
$active_page = 'reservations';

$books = db()->query('SELECT * FROM books ORDER BY title')->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Reserve</p>
    <h1 class="section-title">Reserve a Book</h1>
  </div>
</div>

<div class="card p-4">
  <div class="table-responsive">
    <table class="table align-middle" data-datatable>
      <thead>
        <tr>
          <th>Title</th>
          <th>Author</th>
          <th>Available</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($books as $book) : ?>
          <tr>
            <td><?php echo htmlspecialchars($book['title']); ?></td>
            <td><?php echo htmlspecialchars($book['author']); ?></td>
            <td><?php echo (int)$book['copies_available']; ?> / <?php echo (int)$book['copies_total']; ?></td>
            <td>
              <form method="post" action="<?php echo base_url(); ?>/api/reserve_book.php" class="js-api-form">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                <button class="btn btn-sm btn-soft-warning" type="submit">Reserve</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
