<?php
require_once __DIR__ . '/../includes/user_or_admin.php';

$page_title = 'History';
$is_admin = false;
$active_page = 'returns';

$user = current_user();
$user_id = $user['id'];

$borrows = db()->prepare("SELECT b.id, bk.title, b.borrowed_at, b.returned_at, b.status
  FROM borrows b
  JOIN books bk ON bk.id = b.book_id
  WHERE b.user_id = ?
  ORDER BY b.borrowed_at DESC");
$borrows->execute([$user_id]);
$borrowRows = $borrows->fetchAll();

$reservations = db()->prepare("SELECT r.id, bk.title, r.reserved_at, r.status
  FROM reservations r
  JOIN books bk ON bk.id = r.book_id
  WHERE r.user_id = ?
  ORDER BY r.reserved_at DESC");
$reservations->execute([$user_id]);
$reserveRows = $reservations->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">History</p>
    <h1 class="section-title">Borrow & Reservation History</h1>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-7" id="returns">
    <div class="card p-4">
      <h5 class="section-title mb-3">Borrow History</h5>
      <div class="table-responsive">
        <table class="table align-middle" data-datatable>
          <thead>
            <tr>
              <th>Book</th>
              <th>Borrowed</th>
              <th>Returned</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($borrowRows as $borrow) : ?>
              <tr>
                <td><?php echo htmlspecialchars($borrow['title']); ?></td>
                <td><?php echo date('M d, Y', strtotime($borrow['borrowed_at'])); ?></td>
                <td><?php echo $borrow['returned_at'] ? date('M d, Y', strtotime($borrow['returned_at'])) : '-'; ?></td>
                <td>
                  <?php if ($borrow['status'] === 'returned') : ?>
                    <span class="badge badge-status badge-returned">Returned</span>
                  <?php else : ?>
                    <span class="badge badge-status badge-borrowed">Borrowed</span>
                    <form method="post" action="<?php echo base_url(); ?>/api/return_book.php" class="js-api-form d-inline">
                      <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                      <input type="hidden" name="borrow_id" value="<?php echo $borrow['id']; ?>">
                      <button class="btn btn-sm btn-outline-primary" type="submit">Return</button>
                    </form>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card p-4">
      <h5 class="section-title mb-3">Reservation History</h5>
      <div class="table-responsive">
        <table class="table align-middle" data-datatable>
          <thead>
            <tr>
              <th>Book</th>
              <th>Reserved</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($reserveRows as $reserve) : ?>
              <tr>
                <td><?php echo htmlspecialchars($reserve['title']); ?></td>
                <td><?php echo date('M d, Y', strtotime($reserve['reserved_at'])); ?></td>
                <td>
                  <span class="badge badge-status badge-reserved"><?php echo ucfirst($reserve['status']); ?></span>
                  <?php if ($reserve['status'] === 'active') : ?>
                    <form method="post" action="<?php echo base_url(); ?>/api/cancel_reserve.php" class="js-api-form d-inline">
                      <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                      <input type="hidden" name="reservation_id" value="<?php echo $reserve['id']; ?>">
                      <button class="btn btn-sm btn-outline-danger" type="submit">Cancel</button>
                    </form>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
