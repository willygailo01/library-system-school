<?php
require_once __DIR__ . '/../includes/user_or_admin.php';

$page_title = 'User Dashboard';
$is_admin = false;
$active_page = 'dashboard';

$user = current_user();
$user_id = $user['id'];

$books = db()->query('SELECT * FROM books ORDER BY created_at DESC LIMIT 12')->fetchAll();

$historyBorrows = db()->prepare("SELECT b.id, bk.title, b.borrowed_at, b.returned_at, b.status
  FROM borrows b
  JOIN books bk ON bk.id = b.book_id
  WHERE b.user_id = ?
  ORDER BY b.borrowed_at DESC
  LIMIT 5");
$historyBorrows->execute([$user_id]);
$borrows = $historyBorrows->fetchAll();

$reservationsStmt = db()->prepare("SELECT r.id, bk.title, r.reserved_at, r.status
  FROM reservations r
  JOIN books bk ON bk.id = r.book_id
  WHERE r.user_id = ?
  ORDER BY r.reserved_at DESC
  LIMIT 5");
$reservationsStmt->execute([$user_id]);
$reservations = $reservationsStmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Welcome</p>
    <h1 class="section-title">Hello, <?php echo htmlspecialchars($user['name']); ?>!</h1>
    <p class="text-muted">Find a new book, track returns, and manage reservations.</p>
  </div>
</div>

<section class="mb-4" id="books">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="section-title mb-0">Available Books</h4>
    <a class="btn btn-soft" href="<?php echo base_url(); ?>/user/borrow.php">Borrow a Book</a>
  </div>
  <div class="row g-3">
    <?php foreach ($books as $book) : ?>
      <div class="col-sm-6 col-lg-4 col-xl-3">
        <div class="card p-3 h-100 card-hover">
          <h6 class="fw-semibold mb-1"><?php echo htmlspecialchars($book['title']); ?></h6>
          <p class="text-muted small mb-2"><?php echo htmlspecialchars($book['author']); ?></p>
          <div class="d-flex justify-content-between align-items-center mb-3">
            <?php if ((int)$book['copies_available'] > 0) : ?>
              <span class="badge badge-status badge-returned">Available</span>
            <?php else : ?>
              <span class="badge badge-status badge-borrowed">Borrowed</span>
            <?php endif; ?>
            <span class="text-muted small"><?php echo (int)$book['copies_available']; ?> left</span>
          </div>
          <?php if ((int)$book['copies_available'] > 0) : ?>
            <form method="post" action="<?php echo base_url(); ?>/api/borrow_book.php" class="js-api-form">
              <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
              <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
              <button class="btn btn-primary btn-sm w-100" type="submit">Borrow</button>
            </form>
          <?php else : ?>
            <form method="post" action="<?php echo base_url(); ?>/api/reserve_book.php" class="js-api-form">
              <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
              <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
              <button class="btn btn-soft-warning btn-sm w-100" type="submit">Reserve</button>
            </form>
          <?php endif; ?>
          <?php if ((int)$book['copies_available'] > 0) : ?>
            <a href="<?php echo base_url(); ?>/user/reserve.php" class="btn btn-outline-warning btn-sm w-100 mt-2">Reserve</a>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="card p-4 h-100">
      <h5 class="section-title mb-3">Borrow History</h5>
      <?php if (!$borrows) : ?>
        <p class="text-muted">No borrow history yet.</p>
      <?php else : ?>
        <div class="table-responsive">
          <table class="table align-middle">
            <thead>
              <tr>
                <th>Book</th>
                <th>Borrowed</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($borrows as $borrow) : ?>
                <tr>
                  <td><?php echo htmlspecialchars($borrow['title']); ?></td>
                  <td><?php echo date('M d, Y', strtotime($borrow['borrowed_at'])); ?></td>
                  <td>
                    <?php if ($borrow['status'] === 'returned') : ?>
                      <span class="badge badge-status badge-returned">Returned</span>
                    <?php else : ?>
                      <span class="badge badge-status badge-borrowed">Borrowed</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card p-4 h-100">
      <h5 class="section-title mb-3">Reservation History</h5>
      <?php if (!$reservations) : ?>
        <p class="text-muted">No reservations yet.</p>
      <?php else : ?>
        <div class="table-responsive">
          <table class="table align-middle">
            <thead>
              <tr>
                <th>Book</th>
                <th>Reserved</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($reservations as $reservation) : ?>
                <tr>
                  <td><?php echo htmlspecialchars($reservation['title']); ?></td>
                  <td><?php echo date('M d, Y', strtotime($reservation['reserved_at'])); ?></td>
                  <td>
                    <span class="badge badge-status badge-reserved"><?php echo ucfirst($reservation['status']); ?></span>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
