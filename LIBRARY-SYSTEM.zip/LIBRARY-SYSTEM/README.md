# Library Management System

A modern PHP + MySQL Library Management System with role-based access (Admin/User), borrowing and reservation workflows, reporting, and REST-style API endpoints.

## Requirements

- PHP 8+
- MySQL 5.7+ / MariaDB
- Apache/Nginx with PHP extensions (PDO)

## Setup

1. Create the database and tables:
   ```sql
   source /opt/lampp/htdocs/library-system/database/library.sql
   ```
2. Create SQL views for reports:
   ```sql
   source /opt/lampp/htdocs/library-system/database/reports_views.sql
   ```
3. Update database credentials in `config/database.php` if needed.
4. Launch the app and open `index.php`.

### Default Admin Account

- Email: `admin@library.com`
- Password: `password`

## Features

### User Features
- **Dashboard** - View available books, recent borrows, recent reservations
- **Borrow Books** - Borrow available books directly from dashboard or borrow page
- **Reserve Books** - Reserve books that are currently borrowed
- **Return Books** - Return borrowed books from history page
- **Cancel Reservations** - Cancel active reservations
- **View History** - Complete borrow and reservation history

### Admin Features
- **Dashboard** - Overview with stats (books, borrowed, returned, reserved, overdue)
- **Book Management** - Add, edit, delete books
- **Borrow Management** - Create borrows for users, view active borrows
- **Return Management** - Mark books as returned, auto-fulfill reservations
- **Reservation Management** - Fulfill or cancel reservations
- **User Management** - Create, edit, delete users
- **Reports** - Borrow, Return, Reservation, and Full Activity reports with filters

### System Features
- Secure login and registration with hashed passwords
- Role-based access (Admin/User)
- CSRF protection
- Overdue tracking
- Auto-fulfill reservations when books are returned
- REST-style JSON API endpoints
- Responsive UI with Bootstrap 5, DataTables, and Chart.js

## API Endpoints

### Book APIs
- `POST /api/add_book.php` - Add new book (Admin only)
- `POST /api/update_book.php` - Update book (Admin only)
- `POST /api/delete_book.php` - Delete book (Admin only)

### Borrow APIs
- `POST /api/borrow_book.php` - Borrow a book (User/Admin)
- `POST /api/return_book.php` - Return a book (User/Admin)

### Reservation APIs
- `POST /api/reserve_book.php` - Reserve a book (User)
- `POST /api/cancel_reserve.php` - Cancel reservation (User/Admin)
- `POST /api/fulfill_reserve.php` - Fulfill reservation (Admin only)

All endpoints respond with JSON and require authentication + CSRF token.

## Project Structure

```
library-system/
├── admin/              # Admin pages
│   ├── dashboard.php
│   ├── books.php
│   ├── borrow.php
│   ├── returns.php
│   ├── reservations.php
│   ├── users.php
│   ├── user_view.php
│   └── reports/       # Report pages
├── api/               # API endpoints
├── auth/              # Login, Register, Logout
├── config/            # Database configuration
├── database/          # SQL files
├── includes/          # Shared PHP files
├── user/              # User pages
└── assets/            # CSS, JS, images
```

## Security

- Passwords are hashed using BCRYPT
- CSRF token protection on all forms
- Role-based access control
- SQL injection protection via PDO prepared statements
- XSS protection via htmlspecialchars()

## License

MIT
