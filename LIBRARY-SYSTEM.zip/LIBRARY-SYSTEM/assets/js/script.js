/* global bootstrap, Chart, $ */
const LMS = {
  toast(message, type = 'success') {
    const toastEl = document.getElementById('appToast');
    if (!toastEl) return;
    const body = toastEl.querySelector('.toast-body');
    const header = toastEl.querySelector('.toast-header strong');
    if (body) body.textContent = message;
    if (header) header.textContent = type === 'error' ? 'Error' : type === 'warning' ? 'Warning' : 'Success';
    toastEl.classList.remove('text-bg-success', 'text-bg-danger', 'text-bg-warning');
    if (type === 'error') toastEl.classList.add('text-bg-danger');
    else if (type === 'warning') toastEl.classList.add('text-bg-warning');
    else toastEl.classList.add('text-bg-success');
    bootstrap.Toast.getOrCreateInstance(toastEl).show();
  },
  spinner: {
    show() {
      const spinner = document.querySelector('.spinner-overlay');
      if (spinner) spinner.classList.add('active');
    },
    hide() {
      const spinner = document.querySelector('.spinner-overlay');
      if (spinner) spinner.classList.remove('active');
    }
  },
  csrf() {
    return document.querySelector('meta[name="csrf-token"]')?.content || '';
  }
};

window.LMS = LMS;

const attachPasswordToggles = () => {
  document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.target);
      if (!target) return;
      const isPassword = target.type === 'password';
      target.type = isPassword ? 'text' : 'password';
      btn.textContent = isPassword ? 'Hide' : 'Show';
    });
  });
};

const initDataTables = () => {
  if (typeof $ === 'undefined' || !$.fn || !$.fn.DataTable) return;
  document.querySelectorAll('[data-datatable]').forEach((table) => {
    if (!$.fn.DataTable.isDataTable(table)) {
      $(table).DataTable({
        responsive: true,
        pageLength: 8,
        lengthChange: false,
        language: {
          search: 'Search:'
        }
      });
    }
  });
};

const initCharts = () => {
  const chartEl = document.getElementById('reportsChart');
  if (!chartEl || typeof Chart === 'undefined') return;
  const ctx = chartEl.getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Borrowed', 'Returned', 'Reserved'],
      datasets: [
        {
          label: 'Books',
          data: chartEl.dataset.values.split(',').map((val) => Number(val)),
          backgroundColor: ['#1e3a8a', '#16a34a', '#f59e0b']
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      }
    }
  });
};

const initStackTables = () => {
  document.querySelectorAll('table.table').forEach((table) => {
    const headers = Array.from(table.querySelectorAll('thead th')).map((th) => th.textContent.trim());
    if (!headers.length) return;
    table.classList.add('stack-mobile');
    table.querySelectorAll('tbody tr').forEach((row) => {
      Array.from(row.children).forEach((cell, idx) => {
        if (!cell.dataset.label) cell.dataset.label = headers[idx] || '';
      });
    });
  });
};

const sendApiRequest = async (url, payload) => {
  LMS.spinner.show();
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': LMS.csrf()
      },
      body: JSON.stringify(payload)
    });
    const data = await response.json();
    LMS.toast(data.message || 'Done', data.status === 'error' ? 'error' : 'success');
    if (data.redirect) window.location.href = data.redirect;
    if (data.reload) window.location.reload();
  } catch (error) {
    LMS.toast('Something went wrong.', 'error');
  } finally {
    LMS.spinner.hide();
  }
};

const attachAjaxButtons = () => {
  document.querySelectorAll('[data-api]').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      const url = btn.dataset.api;
      const payload = JSON.parse(btn.dataset.payload || '{}');
      payload.csrf_token = payload.csrf_token || LMS.csrf();
      sendApiRequest(url, payload);
    });
  });
};

const attachApiForms = () => {
  document.querySelectorAll('.js-api-form').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const payload = Object.fromEntries(new FormData(form).entries());
      payload.csrf_token = payload.csrf_token || LMS.csrf();
      sendApiRequest(form.action, payload);
    });
  });
};

const initBookModal = () => {
  const modalEl = document.getElementById('bookModal');
  if (!modalEl) return;
  const form = modalEl.querySelector('form');
  const idField = form?.querySelector('[name="id"]');
  const titleField = form?.querySelector('[name="title"]');
  const authorField = form?.querySelector('[name="author"]');
  const isbnField = form?.querySelector('[name="isbn"]');
  const categoryField = form?.querySelector('[name="category"]');
  const copiesField = form?.querySelector('[name="copies_total"]');
  const modalTitle = modalEl.querySelector('.modal-title');

  document.querySelectorAll('[data-book-add]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (modalTitle) modalTitle.textContent = 'Add Book';
      if (idField) idField.value = '';
      if (titleField) titleField.value = '';
      if (authorField) authorField.value = '';
      if (isbnField) isbnField.value = '';
      if (categoryField) categoryField.value = '';
      if (copiesField) copiesField.value = 1;
    });
  });

  document.querySelectorAll('[data-book-edit]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (modalTitle) modalTitle.textContent = 'Edit Book';
      if (idField) idField.value = btn.dataset.id || '';
      if (titleField) titleField.value = btn.dataset.title || '';
      if (authorField) authorField.value = btn.dataset.author || '';
      if (isbnField) isbnField.value = btn.dataset.isbn || '';
      if (categoryField) categoryField.value = btn.dataset.category || '';
      if (copiesField) copiesField.value = btn.dataset.copies || 1;
    });
  });

  if (form) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const payload = Object.fromEntries(formData.entries());
      payload.csrf_token = LMS.csrf();
      
      const bookId = payload.id;
      const apiUrl = bookId ? '/api/update_book.php' : '/api/add_book.php';
      
      LMS.spinner.show();
      fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': LMS.csrf()
        },
        body: JSON.stringify(payload)
      })
      .then(res => res.json())
      .then(data => {
        LMS.toast(data.message || 'Done', data.status === 'error' ? 'error' : 'success');
        if (data.status === 'success') {
          const bsModal = bootstrap.Modal.getInstance(modalEl);
          if (bsModal) bsModal.hide();
        }
        if (data.reload) window.location.reload();
      })
      .catch(() => LMS.toast('Something went wrong.', 'error'))
      .finally(() => LMS.spinner.hide());
    });
  }
};

document.addEventListener('DOMContentLoaded', () => {
  attachPasswordToggles();
  initDataTables();
  initCharts();
  initStackTables();
  attachAjaxButtons();
  attachApiForms();
  initBookModal();
  document.body.classList.add('page-loaded');
});
