<?php
require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

if (!isset($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function csrf_token(): string
{
  return $_SESSION['csrf_token'] ?? '';
}

function verify_csrf(?string $token): bool
{
  return $token && hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function base_url(): string
{
  static $cached = null;
  if ($cached !== null) {
    return $cached;
  }
  $project_root = dirname(__DIR__);
  $doc_root = $_SERVER['DOCUMENT_ROOT'] ?? '';
  $base = '';
  if ($doc_root && strpos($project_root, $doc_root) === 0) {
    $base = str_replace('\\', '/', substr($project_root, strlen($doc_root)));
  }
  $base = rtrim($base, '/');
  $cached = $base;
  return $cached;
}

function redirect(string $path): void
{
  header('Location: ' . base_url() . $path);
  exit;
}

function is_logged_in(): bool
{
  return !empty($_SESSION['user']);
}

function is_admin(): bool
{
  return is_logged_in() && ($_SESSION['user']['role'] ?? '') === 'admin';
}

function current_user(): ?array
{
  return $_SESSION['user'] ?? null;
}

function set_flash(string $type, string $message): void
{
  $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
  if (empty($_SESSION['flash'])) {
    return null;
  }
  $flash = $_SESSION['flash'];
  unset($_SESSION['flash']);
  return $flash;
}

function json_response(array $data, int $status = 200): void
{
  http_response_code($status);
  header('Content-Type: application/json');
  echo json_encode($data);
  exit;
}
