<?php
require_once __DIR__ . '/session.php';

if (!is_logged_in()) {
  set_flash('warning', 'Please log in first.');
  redirect('/auth/login.php');
}

if (!is_admin()) {
  set_flash('error', 'Access denied. Admins only.');
  redirect('/user/dashboard.php');
}
