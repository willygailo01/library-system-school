<?php
require_once __DIR__ . '/session.php';

$page_title = $page_title ?? 'Library System';
$is_admin = $is_admin ?? false;
$active_page = $active_page ?? '';
$base = base_url();

$dashboard_href = $is_admin ? $base . '/admin/dashboard.php' : $base . '/user/dashboard.php';
$nav_items = [
  ['key' => 'dashboard', 'label' => 'Dashboard', 'href' => $dashboard_href],
  ['key' => 'books', 'label' => 'Books', 'href' => $is_admin ? $base . '/admin/books.php' : $base . '/user/dashboard.php#books'],
  ['key' => 'borrow', 'label' => 'Borrow', 'href' => $is_admin ? $base . '/admin/borrow.php' : $base . '/user/borrow.php'],
  ['key' => 'returns', 'label' => 'Returns', 'href' => $is_admin ? $base . '/admin/returns.php' : $base . '/user/history.php#returns'],
  ['key' => 'reservations', 'label' => 'Reservations', 'href' => $is_admin ? $base . '/admin/reservations.php' : $base . '/user/reserve.php']
];

if ($is_admin) {
  $nav_items[] = ['key' => 'reports', 'label' => 'Reports', 'href' => $base . '/admin/reports/full_report.php'];
  $nav_items[] = ['key' => 'users', 'label' => 'Users', 'href' => $base . '/admin/users.php'];
}

$flash = get_flash();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo csrf_token(); ?>">
  <title><?php echo htmlspecialchars($page_title); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css" rel="stylesheet">
  <link href="<?php echo $base; ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
  <div class="page-shell">
    <nav class="navbar navbar-expand-lg fixed-top navbar-light">
      <div class="container">
        <a class="navbar-brand" href="<?php echo $dashboard_href; ?>">
          <span class="brand-badge">LS</span>Library System
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileNav" aria-controls="mobileNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse">
          <ul class="navbar-nav ms-auto gap-lg-2">
            <?php foreach ($nav_items as $item) : ?>
              <li class="nav-item">
                <a class="nav-link <?php echo $active_page === $item['key'] ? 'active' : ''; ?>" href="<?php echo $item['href']; ?>">
                  <?php echo $item['label']; ?>
                </a>
              </li>
            <?php endforeach; ?>
            <li class="nav-item">
              <a class="btn btn-soft ms-lg-3" href="<?php echo $base; ?>/auth/logout.php">Logout</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="offcanvas offcanvas-end" tabindex="-1" id="mobileNav" aria-labelledby="mobileNavLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="mobileNavLabel">Menu</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <div class="d-grid gap-2 mb-3">
          <a class="btn btn-primary" href="<?php echo $dashboard_href; ?>">Go to Dashboard</a>
        </div>
        <ul class="navbar-nav">
          <?php foreach ($nav_items as $item) : ?>
            <li class="nav-item">
              <a class="nav-link <?php echo $active_page === $item['key'] ? 'active' : ''; ?>" href="<?php echo $item['href']; ?>">
                <?php echo $item['label']; ?>
              </a>
            </li>
          <?php endforeach; ?>
          <li class="nav-item mt-2">
            <a class="btn btn-soft" href="<?php echo $base; ?>/auth/logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>

    <main class="main-content">
      <div class="container">
        <?php if ($flash) : ?>
          <div class="alert alert-<?php echo $flash['type'] === 'error' ? 'danger' : $flash['type']; ?> alert-dismissible fade show" role="alert">
            <?php echo htmlspecialchars($flash['message']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>
