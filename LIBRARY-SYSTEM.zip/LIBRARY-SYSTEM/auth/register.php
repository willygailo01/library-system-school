<?php
require_once __DIR__ . '/../includes/session.php';

if (is_logged_in()) {
  redirect(is_admin() ? '/admin/dashboard.php' : '/user/dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $token = $_POST['csrf_token'] ?? '';
  if (!verify_csrf($token)) {
    $error = 'Invalid session token. Please refresh and try again.';
  } else {
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
      $error = 'All fields are required.';
    } elseif (strlen($password) < 6) {
      $error = 'Password must be at least 6 characters.';
    } else {
      $stmt = db()->prepare('SELECT id FROM users WHERE email = ?');
      $stmt->execute([$email]);
      if ($stmt->fetch()) {
        $error = 'Email already registered.';
      } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $insert = db()->prepare('INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)');
        $insert->execute([$name, $email, $hash, 'user']);
        set_flash('success', 'Registration complete. Please log in.');
        redirect('/auth/login.php');
      }
    }
  }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Register | Library System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
  <div class="page-shell">
    <main class="main-content">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-5">
            <div class="card p-4">
              <h3 class="section-title mb-2">Create Account</h3>
              <p class="text-muted">Start borrowing and reserving books today.</p>
              <?php if ($error) : ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
              <?php endif; ?>
              <form method="post" class="mt-3">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                <div class="form-floating mb-3">
                  <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Full name" required>
                  <label for="full_name">Full name</label>
                </div>
                <div class="form-floating mb-3">
                  <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                  <label for="email">Email address</label>
                </div>
                <div class="form-floating mb-3 position-relative">
                  <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                  <label for="password">Password</label>
                  <button type="button" class="btn btn-link position-absolute top-50 end-0 translate-middle-y me-2" data-toggle-password data-target="password">Show</button>
                </div>
                <button class="btn btn-primary w-100" type="submit">Create Account</button>
                <p class="text-center text-muted mt-3">Already have an account? <a href="<?php echo base_url(); ?>/auth/login.php">Login</a></p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url(); ?>/assets/js/script.js"></script>
  
  <div class="toast-container position-fixed bottom-0 end-0 p-3">
    <div id="appToast" class="toast text-bg-success" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="toast-header">
        <strong class="me-auto">Success</strong>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
      <div class="toast-body">Action completed.</div>
    </div>
  </div>

  <div class="spinner-overlay">
    <div class="spinner-border text-light" role="status">
      <span class="visually-hidden">Loading...</span>
    </div>
  </div>
</body>
</html>
