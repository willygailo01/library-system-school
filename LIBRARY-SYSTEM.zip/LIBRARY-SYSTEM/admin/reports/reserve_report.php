<?php
require_once __DIR__ . '/../../includes/admin_guard.php';

$page_title = 'Reservation Report';
$is_admin = true;
$active_page = 'reports';

$conditions = [];
$params = [];

if (!empty($_GET['start_date'])) {
  $conditions[] = 'reserved_at >= ?';
  $params[] = $_GET['start_date'] . ' 00:00:00';
}
if (!empty($_GET['end_date'])) {
  $conditions[] = 'reserved_at <= ?';
  $params[] = $_GET['end_date'] . ' 23:59:59';
}
if (!empty($_GET['user'])) {
  $conditions[] = '(user_name LIKE ? OR user_email LIKE ?)';
  $params[] = '%' . $_GET['user'] . '%';
  $params[] = '%' . $_GET['user'] . '%';
}
if (!empty($_GET['book'])) {
  $conditions[] = '(book_title LIKE ? OR book_author LIKE ?)';
  $params[] = '%' . $_GET['book'] . '%';
  $params[] = '%' . $_GET['book'] . '%';
}
if (!empty($_GET['status'])) {
  $conditions[] = 'status = ?';
  $params[] = $_GET['status'];
}

$sql = 'SELECT * FROM view_reserve_report';
if ($conditions) {
  $sql .= ' WHERE ' . implode(' AND ', $conditions);
}
$sql .= ' ORDER BY reserved_at DESC';

$stmt = db()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Reports</p>
    <h1 class="section-title">Reservation Report</h1>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-soft" type="button">Export PDF</button>
    <button class="btn btn-soft" type="button">Export Excel</button>
  </div>
</div>

<div class="card p-4 mb-4">
  <h5 class="section-title mb-3">Filter Report</h5>
  <form method="get" class="row g-3">
    <div class="col-md-3">
      <label class="form-label">Start Date</label>
      <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($_GET['start_date'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">End Date</label>
      <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($_GET['end_date'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">User</label>
      <input type="text" name="user" class="form-control" placeholder="Name or email" value="<?php echo htmlspecialchars($_GET['user'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Book</label>
      <input type="text" name="book" class="form-control" placeholder="Title or author" value="<?php echo htmlspecialchars($_GET['book'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Status</label>
      <select class="form-select" name="status">
        <option value="">All</option>
        <option value="active" <?php echo ($_GET['status'] ?? '') === 'active' ? 'selected' : ''; ?>>Active</option>
        <option value="fulfilled" <?php echo ($_GET['status'] ?? '') === 'fulfilled' ? 'selected' : ''; ?>>Fulfilled</option>
        <option value="cancelled" <?php echo ($_GET['status'] ?? '') === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
      </select>
    </div>
    <div class="col-12">
      <button class="btn btn-primary" type="submit">Apply Filters</button>
      <a class="btn btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/reserve_report.php">Reset</a>
    </div>
  </form>
</div>

<div class="card p-4">
  <h5 class="section-title mb-3">Reservations</h5>
  <div class="table-responsive">
    <table class="table align-middle" data-datatable>
      <thead>
        <tr>
          <th>User</th>
          <th>Email</th>
          <th>Book</th>
          <th>Author</th>
          <th>Reserved</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td><?php echo htmlspecialchars($row['user_name']); ?></td>
            <td><?php echo htmlspecialchars($row['user_email']); ?></td>
            <td><?php echo htmlspecialchars($row['book_title']); ?></td>
            <td><?php echo htmlspecialchars($row['book_author']); ?></td>
            <td><?php echo date('M d, Y', strtotime($row['reserved_at'])); ?></td>
            <td>
              <?php 
                $badgeClass = 'badge-reserved';
                if ($row['status'] === 'fulfilled') $badgeClass = 'badge-returned';
                if ($row['status'] === 'cancelled') $badgeClass = 'badge-overdue';
              ?>
              <span class="badge badge-status <?php echo $badgeClass; ?>"><?php echo ucfirst($row['status']); ?></span>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
