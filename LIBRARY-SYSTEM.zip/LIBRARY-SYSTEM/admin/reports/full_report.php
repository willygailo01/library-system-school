<?php
require_once __DIR__ . '/../../includes/admin_guard.php';

$page_title = 'Full Report';
$is_admin = true;
$active_page = 'reports';

$conditions = [];
$params = [];

if (!empty($_GET['start_date'])) {
  $conditions[] = 'record_date >= ?';
  $params[] = $_GET['start_date'] . ' 00:00:00';
}
if (!empty($_GET['end_date'])) {
  $conditions[] = 'record_date <= ?';
  $params[] = $_GET['end_date'] . ' 23:59:59';
}
if (!empty($_GET['user'])) {
  $conditions[] = '(user_name LIKE ? OR user_email LIKE ?)';
  $params[] = '%' . $_GET['user'] . '%';
  $params[] = '%' . $_GET['user'] . '%';
}
if (!empty($_GET['book'])) {
  $conditions[] = '(book_title LIKE ? OR book_author LIKE ?)';
  $params[] = '%' . $_GET['book'] . '%';
  $params[] = '%' . $_GET['book'] . '%';
}
if (!empty($_GET['type'])) {
  $conditions[] = 'record_type = ?';
  $params[] = $_GET['type'];
}

$sql = 'SELECT * FROM view_full_report';
if ($conditions) {
  $sql .= ' WHERE ' . implode(' AND ', $conditions);
}
$sql .= ' ORDER BY record_date DESC';

$stmt = db()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Reports</p>
    <h1 class="section-title">Full Activity Report</h1>
  </div>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/borrow_report.php">Borrow Report</a>
    <a class="btn btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/return_report.php">Return Report</a>
    <a class="btn btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/reserve_report.php">Reserve Report</a>
  </div>
</div>

<div class="card p-4 mb-4">
  <h5 class="section-title mb-3">Filter Activity</h5>
  <form method="get" class="row g-3">
    <div class="col-md-2">
      <label class="form-label">Start Date</label>
      <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($_GET['start_date'] ?? ''); ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label">End Date</label>
      <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($_GET['end_date'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">User</label>
      <input type="text" name="user" class="form-control" placeholder="Name or email" value="<?php echo htmlspecialchars($_GET['user'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Book</label>
      <input type="text" name="book" class="form-control" placeholder="Title or author" value="<?php echo htmlspecialchars($_GET['book'] ?? ''); ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label">Type</label>
      <select class="form-select" name="type">
        <option value="">All</option>
        <option value="borrow" <?php echo ($_GET['type'] ?? '') === 'borrow' ? 'selected' : ''; ?>>Borrow</option>
        <option value="reservation" <?php echo ($_GET['type'] ?? '') === 'reservation' ? 'selected' : ''; ?>>Reservation</option>
      </select>
    </div>
    <div class="col-12">
      <button class="btn btn-primary" type="submit">Apply Filters</button>
      <a class="btn btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/full_report.php">Reset</a>
    </div>
  </form>
</div>

<div class="card p-4">
  <h5 class="section-title mb-3">All Activity</h5>
  <div class="table-responsive">
    <table class="table align-middle" data-datatable>
      <thead>
        <tr>
          <th>Type</th>
          <th>User</th>
          <th>Email</th>
          <th>Book</th>
          <th>Author</th>
          <th>Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $row) : ?>
          <tr>
            <td><?php echo ucfirst($row['record_type']); ?></td>
            <td><?php echo htmlspecialchars($row['user_name']); ?></td>
            <td><?php echo htmlspecialchars($row['user_email']); ?></td>
            <td><?php echo htmlspecialchars($row['book_title']); ?></td>
            <td><?php echo htmlspecialchars($row['book_author']); ?></td>
            <td><?php echo date('M d, Y', strtotime($row['record_date'])); ?></td>
            <td>
              <?php 
                $badgeClass = 'badge-borrowed';
                if ($row['record_type'] === 'borrow' && $row['status'] === 'returned') {
                  $badgeClass = 'badge-returned';
                } elseif ($row['record_type'] === 'reservation') {
                  if ($row['status'] === 'fulfilled') $badgeClass = 'badge-returned';
                  elseif ($row['status'] === 'cancelled') $badgeClass = 'badge-overdue';
                  else $badgeClass = 'badge-reserved';
                }
              ?>
              <span class="badge badge-status <?php echo $badgeClass; ?>"><?php echo ucfirst($row['status']); ?></span>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
