<?php
require_once __DIR__ . '/../../includes/admin_guard.php';

$page_title = 'Return Report';
$is_admin = true;
$active_page = 'reports';

$conditions = [];
$params = [];

if (!empty($_GET['start_date'])) {
  $conditions[] = 'returned_at >= ?';
  $params[] = $_GET['start_date'] . ' 00:00:00';
}
if (!empty($_GET['end_date'])) {
  $conditions[] = 'returned_at <= ?';
  $params[] = $_GET['end_date'] . ' 23:59:59';
}
if (!empty($_GET['user'])) {
  $conditions[] = '(user_name LIKE ? OR user_email LIKE ?)';
  $params[] = '%' . $_GET['user'] . '%';
  $params[] = '%' . $_GET['user'] . '%';
}
if (!empty($_GET['book'])) {
  $conditions[] = '(book_title LIKE ? OR book_author LIKE ?)';
  $params[] = '%' . $_GET['book'] . '%';
  $params[] = '%' . $_GET['book'] . '%';
}

$sql = 'SELECT * FROM view_return_report';
if ($conditions) {
  $sql .= ' WHERE ' . implode(' AND ', $conditions);
}
$sql .= ' ORDER BY returned_at DESC';

$stmt = db()->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

include __DIR__ . '/../../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Reports</p>
    <h1 class="section-title">Return Report</h1>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-soft" type="button">Export PDF</button>
    <button class="btn btn-soft" type="button">Export Excel</button>
  </div>
</div>

<div class="card p-4 mb-4">
  <h5 class="section-title mb-3">Filter Report</h5>
  <form method="get" class="row g-3">
    <div class="col-md-3">
      <label class="form-label">Start Date</label>
      <input type="date" name="start_date" class="form-control" value="<?php echo htmlspecialchars($_GET['start_date'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">End Date</label>
      <input type="date" name="end_date" class="form-control" value="<?php echo htmlspecialchars($_GET['end_date'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">User</label>
      <input type="text" name="user" class="form-control" placeholder="Name or email" value="<?php echo htmlspecialchars($_GET['user'] ?? ''); ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label">Book</label>
      <input type="text" name="book" class="form-control" placeholder="Title or author" value="<?php echo htmlspecialchars($_GET['book'] ?? ''); ?>">
    </div>
    <div class="col-12">
      <button class="btn btn-primary" type="submit">Apply Filters</button>
      <a class="btn btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/return_report.php">Reset</a>
    </div>
  </form>
</div>

<div class="card p-4">
  <h5 class="section-title mb-3">Returned Books</h5>
  <div class="table-responsive">
    <table class="table align-middle" data-datatable>
      <thead>
        <tr>
          <th>User</th>
          <th>Email</th>
          <th>Book</th>
          <th>Author</th>
          <th>Borrowed</th>
          <th>Returned</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $row) : ?>
          <?php 
            $isOverdue = isset($row['returned_at']) && isset($row['due_at']) && strtotime($row['returned_at']) > strtotime($row['due_at']);
          ?>
          <tr<?php echo $isOverdue ? ' class="table-danger"' : ''; ?>>
            <td><?php echo htmlspecialchars($row['user_name']); ?></td>
            <td><?php echo htmlspecialchars($row['user_email']); ?></td>
            <td><?php echo htmlspecialchars($row['book_title']); ?></td>
            <td><?php echo htmlspecialchars($row['book_author']); ?></td>
            <td><?php echo date('M d, Y', strtotime($row['borrowed_at'])); ?></td>
            <td>
              <?php if ($isOverdue) : ?>
                <span class="badge badge-status badge-overdue">Late</span><br>
              <?php endif; ?>
              <?php echo date('M d, Y', strtotime($row['returned_at'])); ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
