<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$page_title = 'Return Management';
$is_admin = true;
$active_page = 'returns';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('error', 'Invalid session token.');
    redirect('/admin/returns.php');
  }

  $borrow_id = (int)($_POST['borrow_id'] ?? 0);
  if ($borrow_id <= 0) {
    set_flash('error', 'Invalid borrow record.');
    redirect('/admin/returns.php');
  }

  $stmt = db()->prepare("SELECT book_id FROM borrows WHERE id = ? AND status = 'borrowed'");
  $stmt->execute([$borrow_id]);
  $borrow = $stmt->fetch();
  if (!$borrow) {
    set_flash('error', 'Borrow record not found.');
    redirect('/admin/returns.php');
  }

  $update = db()->prepare("UPDATE borrows SET status = 'returned', returned_at = NOW() WHERE id = ?");
  $update->execute([$borrow_id]);

  $bookUpdate = db()->prepare('UPDATE books SET copies_available = copies_available + 1 WHERE id = ?');
  $bookUpdate->execute([$borrow['book_id']]);

  $reservations = db()->prepare("SELECT id FROM reservations WHERE book_id = ? AND status = 'active' ORDER BY reserved_at ASC LIMIT 1");
  $reservations->execute([$borrow['book_id']]);
  $nextReservation = $reservations->fetch();
  if ($nextReservation) {
    $fulfill = db()->prepare("UPDATE reservations SET status = 'fulfilled', fulfilled_at = NOW() WHERE id = ?");
    $fulfill->execute([$nextReservation['id']]);
    
    $bookUpdate2 = db()->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ?');
    $bookUpdate2->execute([$borrow['book_id']]);
  }

  set_flash('success', 'Book returned successfully.');
  redirect('/admin/returns.php');
}

$returns = db()->query("SELECT b.id, u.full_name, bk.title, b.borrowed_at, b.due_at
  FROM borrows b
  JOIN users u ON u.id = b.user_id
  JOIN books bk ON bk.id = b.book_id
  WHERE b.status = 'borrowed'
  ORDER BY b.due_at ASC")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Circulation</p>
    <h1 class="section-title">Return Management</h1>
  </div>
</div>

<div class="card p-4">
  <h5 class="section-title mb-3">Books to Return</h5>
  <div class="table-responsive">
    <table class="table align-middle" data-datatable>
      <thead>
        <tr>
          <th>Borrower</th>
          <th>Book</th>
          <th>Borrowed</th>
          <th>Due</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
          <?php foreach ($returns as $borrow) : ?>
            <?php 
              $isOverdue = strtotime($borrow['due_at']) < time();
            ?>
            <tr<?php echo $isOverdue ? ' class="table-danger"' : ''; ?>>
              <td><?php echo htmlspecialchars($borrow['full_name']); ?></td>
              <td><?php echo htmlspecialchars($borrow['title']); ?></td>
              <td><?php echo date('M d, Y', strtotime($borrow['borrowed_at'])); ?></td>
              <td>
                <?php if ($isOverdue) : ?>
                  <span class="badge badge-status badge-overdue">Overdue</span>
                <?php else : ?>
                  <?php echo date('M d, Y', strtotime($borrow['due_at'])); ?>
                <?php endif; ?>
              </td>
              <td>
                <form method="post">
                  <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                  <input type="hidden" name="borrow_id" value="<?php echo $borrow['id']; ?>">
                  <button class="btn btn-sm btn-primary" type="submit">Mark Returned</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
