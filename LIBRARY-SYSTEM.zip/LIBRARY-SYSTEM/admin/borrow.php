<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$page_title = 'Borrow Management';
$is_admin = true;
$active_page = 'borrow';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('error', 'Invalid session token.');
    redirect('/admin/borrow.php');
  }

  $user_id = (int)($_POST['user_id'] ?? 0);
  $book_id = (int)($_POST['book_id'] ?? 0);
  $due_at = $_POST['due_at'] ?? '';

  if ($user_id <= 0 || $book_id <= 0 || $due_at === '') {
    set_flash('error', 'Please select user, book, and due date.');
    redirect('/admin/borrow.php');
  }

  $bookStmt = db()->prepare('SELECT copies_available FROM books WHERE id = ?');
  $bookStmt->execute([$book_id]);
  $book = $bookStmt->fetch();

  if (!$book || (int)$book['copies_available'] <= 0) {
    set_flash('error', 'Book is not available.');
    redirect('/admin/borrow.php');
  }

  $borrow = db()->prepare('INSERT INTO borrows (user_id, book_id, due_at) VALUES (?, ?, ?)');
  $borrow->execute([$user_id, $book_id, $due_at]);

  $update = db()->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ?');
  $update->execute([$book_id]);

  set_flash('success', 'Borrow recorded successfully.');
  redirect('/admin/borrow.php');
}

$users = db()->query("SELECT id, full_name FROM users WHERE role = 'user' ORDER BY full_name")->fetchAll();
$books = db()->query('SELECT id, title, author, copies_available FROM books WHERE copies_available > 0 ORDER BY title')->fetchAll();
$borrows = db()->query("SELECT b.id, u.full_name, bk.title, b.borrowed_at, b.due_at
  FROM borrows b
  JOIN users u ON u.id = b.user_id
  JOIN books bk ON bk.id = b.book_id
  WHERE b.status = 'borrowed'
  ORDER BY b.borrowed_at DESC")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Circulation</p>
    <h1 class="section-title">Borrow Management</h1>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="card p-4">
      <h5 class="section-title mb-3">New Borrow</h5>
      <form method="post">
        <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
        <div class="mb-3">
          <label class="form-label">User</label>
          <select class="form-select" name="user_id" required>
            <option value="">Select user</option>
            <?php foreach ($users as $user) : ?>
              <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['full_name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Book</label>
          <select class="form-select" name="book_id" required>
            <option value="">Select book</option>
            <?php foreach ($books as $book) : ?>
              <option value="<?php echo $book['id']; ?>"><?php echo htmlspecialchars($book['title']); ?> (<?php echo $book['copies_available']; ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label">Due Date</label>
          <input type="date" class="form-control" name="due_at" value="<?php echo date('Y-m-d', strtotime('+14 days')); ?>" required>
        </div>
        <button class="btn btn-primary w-100" type="submit">Confirm Borrow</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card p-4">
      <h5 class="section-title mb-3">Active Borrows</h5>
      <div class="table-responsive">
        <table class="table align-middle" data-datatable>
          <thead>
            <tr>
              <th>Borrower</th>
              <th>Book</th>
              <th>Borrowed</th>
              <th>Due</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($borrows as $borrow) : ?>
              <tr>
                <td><?php echo htmlspecialchars($borrow['full_name']); ?></td>
                <td><?php echo htmlspecialchars($borrow['title']); ?></td>
                <td><?php echo date('M d, Y', strtotime($borrow['borrowed_at'])); ?></td>
                <td><span class="badge badge-status badge-borrowed"><?php echo date('M d, Y', strtotime($borrow['due_at'])); ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
