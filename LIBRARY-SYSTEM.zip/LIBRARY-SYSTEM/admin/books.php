<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$page_title = 'Manage Books';
$is_admin = true;
$active_page = 'books';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('error', 'Invalid session token.');
    redirect('/admin/books.php');
  }

  $action = $_POST['action'] ?? '';

  if ($action === 'save_book') {
    $id = trim($_POST['id'] ?? '');
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $copies_total = (int)($_POST['copies_total'] ?? 1);

    if ($title === '' || $author === '' || $copies_total < 1) {
      set_flash('error', 'Please fill out required fields.');
      redirect('/admin/books.php');
    }

    if ($id) {
      $stmt = db()->prepare('SELECT copies_total, copies_available FROM books WHERE id = ?');
      $stmt->execute([$id]);
      $current = $stmt->fetch();
      if (!$current) {
        set_flash('error', 'Book not found.');
        redirect('/admin/books.php');
      }
      $borrowed = max(0, (int)$current['copies_total'] - (int)$current['copies_available']);
      $available = max(0, $copies_total - $borrowed);

      $update = db()->prepare('UPDATE books SET title = ?, author = ?, isbn = ?, category = ?, copies_total = ?, copies_available = ? WHERE id = ?');
      $update->execute([$title, $author, $isbn, $category, $copies_total, $available, $id]);
      set_flash('success', 'Book updated successfully.');
    } else {
      $insert = db()->prepare('INSERT INTO books (title, author, isbn, category, copies_total, copies_available) VALUES (?, ?, ?, ?, ?, ?)');
      $insert->execute([$title, $author, $isbn, $category, $copies_total, $copies_total]);
      set_flash('success', 'Book added successfully.');
    }

    redirect('/admin/books.php');
  }

  if ($action === 'delete_book') {
    $id = trim($_POST['id'] ?? '');
    if ($id === '') {
      set_flash('error', 'Invalid request.');
      redirect('/admin/books.php');
    }

    $stmt = db()->prepare("SELECT COUNT(*) FROM borrows WHERE book_id = ? AND status = 'borrowed'");
    $stmt->execute([$id]);
    if ((int)$stmt->fetchColumn() > 0) {
      set_flash('error', 'Cannot delete a book with active borrows.');
      redirect('/admin/books.php');
    }

    $delete = db()->prepare('DELETE FROM books WHERE id = ?');
    $delete->execute([$id]);
    set_flash('success', 'Book deleted successfully.');
    redirect('/admin/books.php');
  }
}

$books = db()->query('SELECT * FROM books ORDER BY created_at DESC')->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Library Inventory</p>
    <h1 class="section-title">Books Management</h1>
  </div>
  <div class="d-flex gap-2">
    <button class="btn btn-primary" type="button" data-book-add data-bs-toggle="modal" data-bs-target="#bookModal">Add Book</button>
    <a class="btn btn-soft" href="<?php echo base_url(); ?>/admin/reports/borrow_report.php">Borrow Report</a>
  </div>
</div>

<div class="card p-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="section-title mb-0">Book Catalog</h5>
  </div>
  <div class="table-responsive">
    <table class="table align-middle" data-datatable>
      <thead>
        <tr>
          <th>Title</th>
          <th>Author</th>
          <th>Category</th>
          <th>Available</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($books as $book) : ?>
          <tr>
            <td><?php echo htmlspecialchars($book['title']); ?></td>
            <td><?php echo htmlspecialchars($book['author']); ?></td>
            <td><?php echo htmlspecialchars($book['category']); ?></td>
            <td><?php echo (int)$book['copies_available']; ?> / <?php echo (int)$book['copies_total']; ?></td>
            <td>
              <div class="d-flex gap-2">
                <button
                  class="btn btn-sm btn-outline-primary"
                  type="button"
                  data-book-edit
                  data-bs-toggle="modal"
                  data-bs-target="#bookModal"
                  data-id="<?php echo $book['id']; ?>"
                  data-title="<?php echo htmlspecialchars($book['title']); ?>"
                  data-author="<?php echo htmlspecialchars($book['author']); ?>"
                  data-isbn="<?php echo htmlspecialchars($book['isbn']); ?>"
                  data-category="<?php echo htmlspecialchars($book['category']); ?>"
                  data-copies="<?php echo (int)$book['copies_total']; ?>"
                >Edit</button>
                <form method="post" onsubmit="return confirm('Delete this book?');">
                  <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                  <input type="hidden" name="action" value="delete_book">
                  <input type="hidden" name="id" value="<?php echo $book['id']; ?>">
                  <button class="btn btn-sm btn-soft-danger" type="submit">Delete</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="bookModal" tabindex="-1" aria-labelledby="bookModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="bookModalLabel">Add Book</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post" id="bookForm">
          <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
          <input type="hidden" name="id" value="">

          <div class="form-floating mb-3">
            <input class="form-control" name="title" placeholder="Title" required>
            <label>Title</label>
          </div>
          <div class="form-floating mb-3">
            <input class="form-control" name="author" placeholder="Author" required>
            <label>Author</label>
          </div>
          <div class="form-floating mb-3">
            <input class="form-control" name="isbn" placeholder="ISBN">
            <label>ISBN</label>
          </div>
          <div class="form-floating mb-3">
            <input class="form-control" name="category" placeholder="Category">
            <label>Category</label>
          </div>
          <div class="form-floating mb-3">
            <input type="number" min="1" class="form-control" name="copies_total" placeholder="Copies" value="1" required>
            <label>Copies Total</label>
          </div>
          <button class="btn btn-primary w-100" type="submit">Save Book</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
