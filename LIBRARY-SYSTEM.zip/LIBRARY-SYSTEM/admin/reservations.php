<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$page_title = 'Reservation Management';
$is_admin = true;
$active_page = 'reservations';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('error', 'Invalid session token.');
    redirect('/admin/reservations.php');
  }

  $action = $_POST['action'] ?? '';
  $reservation_id = (int)($_POST['reservation_id'] ?? 0);
  if ($reservation_id <= 0) {
    set_flash('error', 'Invalid reservation.');
    redirect('/admin/reservations.php');
  }

  $stmt = db()->prepare('SELECT * FROM reservations WHERE id = ?');
  $stmt->execute([$reservation_id]);
  $reservation = $stmt->fetch();

  if (!$reservation) {
    set_flash('error', 'Reservation not found.');
    redirect('/admin/reservations.php');
  }

  if ($action === 'cancel') {
    $update = db()->prepare("UPDATE reservations SET status = 'cancelled', cancelled_at = NOW() WHERE id = ?");
    $update->execute([$reservation_id]);
    set_flash('success', 'Reservation cancelled.');
    redirect('/admin/reservations.php');
  }

  if ($action === 'fulfill') {
    $bookStmt = db()->prepare('SELECT copies_available FROM books WHERE id = ?');
    $bookStmt->execute([$reservation['book_id']]);
    $book = $bookStmt->fetch();

    if (!$book || (int)$book['copies_available'] <= 0) {
      set_flash('error', 'Book not available to fulfill reservation.');
      redirect('/admin/reservations.php');
    }

    $due = (new DateTime('+14 days'))->format('Y-m-d');
    $borrow = db()->prepare('INSERT INTO borrows (user_id, book_id, due_at) VALUES (?, ?, ?)');
    $borrow->execute([$reservation['user_id'], $reservation['book_id'], $due]);

    $update = db()->prepare("UPDATE reservations SET status = 'fulfilled', fulfilled_at = NOW() WHERE id = ?");
    $update->execute([$reservation_id]);

    $bookUpdate = db()->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ?');
    $bookUpdate->execute([$reservation['book_id']]);

    set_flash('success', 'Reservation fulfilled and borrow created.');
    redirect('/admin/reservations.php');
  }
}

$reservations = db()->query("SELECT r.id, r.status, r.reserved_at, u.full_name, bk.title
  FROM reservations r
  JOIN users u ON u.id = r.user_id
  JOIN books bk ON bk.id = r.book_id
  ORDER BY r.reserved_at DESC")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Reservations</p>
    <h1 class="section-title">Reservation Queue</h1>
  </div>
</div>

<div class="card p-4">
  <h5 class="section-title mb-3">Latest Reservations</h5>
  <div class="table-responsive">
    <table class="table align-middle" data-datatable>
      <thead>
        <tr>
          <th>User</th>
          <th>Book</th>
          <th>Reserved</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($reservations as $res) : ?>
          <tr>
            <td><?php echo htmlspecialchars($res['full_name']); ?></td>
            <td><?php echo htmlspecialchars($res['title']); ?></td>
            <td><?php echo date('M d, Y', strtotime($res['reserved_at'])); ?></td>
            <td>
              <?php
                $badgeClass = 'badge-reserved';
                if ($res['status'] === 'fulfilled') $badgeClass = 'badge-returned';
                if ($res['status'] === 'cancelled') $badgeClass = 'badge-borrowed';
              ?>
              <span class="badge badge-status <?php echo $badgeClass; ?>"><?php echo ucfirst($res['status']); ?></span>
            </td>
            <td>
              <?php if ($res['status'] === 'active') : ?>
                <div class="d-flex gap-2">
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="action" value="fulfill">
                    <input type="hidden" name="reservation_id" value="<?php echo $res['id']; ?>">
                    <button class="btn btn-sm btn-primary" type="submit">Fulfill</button>
                  </form>
                  <form method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="action" value="cancel">
                    <input type="hidden" name="reservation_id" value="<?php echo $res['id']; ?>">
                    <button class="btn btn-sm btn-soft-danger" type="submit">Cancel</button>
                  </form>
                </div>
              <?php else : ?>
                <span class="text-muted">No action</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
