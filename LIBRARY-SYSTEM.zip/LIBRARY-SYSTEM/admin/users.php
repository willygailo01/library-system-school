<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$page_title = 'Manage Users';
$is_admin = true;
$active_page = 'users';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!verify_csrf($_POST['csrf_token'] ?? '')) {
    set_flash('error', 'Invalid session token.');
    redirect('/admin/users.php');
  }

  $action = $_POST['action'] ?? '';

  if ($action === 'create_user') {
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? 'user';
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
      set_flash('error', 'All fields are required.');
      redirect('/admin/users.php');
    }

    $check = db()->prepare('SELECT id FROM users WHERE email = ?');
    $check->execute([$email]);
    if ($check->fetch()) {
      set_flash('error', 'Email already exists.');
      redirect('/admin/users.php');
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $insert = db()->prepare('INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)');
    $insert->execute([$name, $email, $hash, $role === 'admin' ? 'admin' : 'user']);
    set_flash('success', 'User created successfully.');
    redirect('/admin/users.php');
  }

  if ($action === 'delete_user') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
      set_flash('error', 'Invalid request.');
      redirect('/admin/users.php');
    }

    if ($id === (int)($_SESSION['user']['id'] ?? 0)) {
      set_flash('error', 'You cannot delete your own account.');
      redirect('/admin/users.php');
    }

    $delete = db()->prepare('DELETE FROM users WHERE id = ?');
    $delete->execute([$id]);
    set_flash('success', 'User deleted successfully.');
    redirect('/admin/users.php');
  }

  if ($action === 'edit_user') {
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['full_name'] ?? '');
    $role = $_POST['role'] ?? 'user';

    if ($id <= 0 || $name === '') {
      set_flash('error', 'Invalid request.');
      redirect('/admin/users.php');
    }

    if ($id === (int)($_SESSION['user']['id'] ?? 0) && $role !== 'admin') {
      set_flash('error', 'You cannot demote yourself.');
      redirect('/admin/users.php');
    }

    $update = db()->prepare('UPDATE users SET full_name = ?, role = ? WHERE id = ?');
    $update->execute([$name, $role === 'admin' ? 'admin' : 'user', $id]);
    set_flash('success', 'User updated successfully.');
    redirect('/admin/users.php');
  }
}

$users = db()->query('SELECT id, full_name, email, role, created_at FROM users ORDER BY created_at DESC')->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Administration</p>
    <h1 class="section-title">User Management</h1>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="card p-4">
      <h5 class="section-title mb-3">Create User</h5>
      <form method="post">
        <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
        <input type="hidden" name="action" value="create_user">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input class="form-control" name="full_name" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="email" class="form-control" name="email" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Role</label>
          <select class="form-select" name="role">
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div class="mb-3 position-relative">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" id="new-user-password" name="password" required>
          <button type="button" class="btn btn-link position-absolute top-50 end-0 translate-middle-y me-2" data-toggle-password data-target="new-user-password">Show</button>
        </div>
        <button class="btn btn-primary w-100" type="submit">Create User</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card p-4">
      <h5 class="section-title mb-3">Registered Users</h5>
      <div class="table-responsive">
        <table class="table align-middle" data-datatable>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Joined</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $user) : ?>
              <tr>
                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td><?php echo ucfirst($user['role']); ?></td>
                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                <td>
                  <div class="d-flex gap-2">
                    <button
                      class="btn btn-sm btn-outline-primary"
                      type="button"
                      data-bs-toggle="modal"
                      data-bs-target="#editUserModal"
                      data-id="<?php echo $user['id']; ?>"
                      data-name="<?php echo htmlspecialchars($user['full_name']); ?>"
                      data-role="<?php echo $user['role']; ?>"
                    >Edit</button>
                    <form method="post" onsubmit="return confirm('Delete this user?');">
                      <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                      <input type="hidden" name="action" value="delete_user">
                      <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                      <button class="btn btn-sm btn-soft-danger" type="submit">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method="post">
          <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
          <input type="hidden" name="action" value="edit_user">
          <input type="hidden" name="id" id="edit_user_id" value="">
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input class="form-control" name="full_name" id="edit_full_name" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Role</label>
            <select class="form-select" name="role" id="edit_role">
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <button class="btn btn-primary w-100" type="submit">Update User</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('[data-bs-target="#editUserModal"]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.getElementById('edit_user_id').value = btn.dataset.id;
      document.getElementById('edit_full_name').value = btn.dataset.name;
      document.getElementById('edit_role').value = btn.dataset.role;
    });
  });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
