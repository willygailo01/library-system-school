<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$page_title = 'Admin Dashboard';
$is_admin = true;
$active_page = 'dashboard';

$stats = [
  'books' => db()->query('SELECT COUNT(*) FROM books')->fetchColumn(),
  'borrowed' => db()->query("SELECT COUNT(*) FROM borrows WHERE status = 'borrowed'")->fetchColumn(),
  'returned' => db()->query("SELECT COUNT(*) FROM borrows WHERE status = 'returned'")->fetchColumn(),
  'reserved' => db()->query("SELECT COUNT(*) FROM reservations WHERE status = 'active'")->fetchColumn(),
  'users' => db()->query('SELECT COUNT(*) FROM users')->fetchColumn()
];

$recentBorrows = db()->query("SELECT b.id, u.full_name, bk.title, b.due_at, b.status
  FROM borrows b
  JOIN users u ON u.id = b.user_id
  JOIN books bk ON bk.id = b.book_id
  ORDER BY b.borrowed_at DESC
  LIMIT 5")->fetchAll();

$overdueCount = db()->query("SELECT COUNT(*) FROM borrows WHERE status = 'borrowed' AND due_at < NOW()")->fetchColumn();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">Admin Panel</p>
    <h1 class="section-title">Dashboard Overview</h1>
    <p class="text-muted">Track circulation, reservations, and system health.</p>
  </div>
  <a class="btn btn-soft" href="<?php echo base_url(); ?>/admin/user_view.php">View User Dashboard</a>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-6 col-xl-2">
    <div class="card card-hover p-3 stat-card">
      <div>
        <p class="text-muted mb-1">Total Books</p>
        <h3 class="mb-0"><?php echo $stats['books']; ?></h3>
      </div>
      <div class="stat-icon"><i class="bi bi-book"></i></div>
    </div>
  </div>
  <div class="col-md-6 col-xl-2">
    <div class="card card-hover p-3 stat-card">
      <div>
        <p class="text-muted mb-1">Borrowed</p>
        <h3 class="mb-0"><?php echo $stats['borrowed']; ?></h3>
      </div>
      <div class="stat-icon"><i class="bi bi-box-arrow-up-right"></i></div>
    </div>
  </div>
  <div class="col-md-6 col-xl-2">
    <div class="card card-hover p-3 stat-card">
      <div>
        <p class="text-muted mb-1">Returned</p>
        <h3 class="mb-0"><?php echo $stats['returned']; ?></h3>
      </div>
      <div class="stat-icon"><i class="bi bi-box-arrow-in-left"></i></div>
    </div>
  </div>
  <div class="col-md-6 col-xl-2">
    <div class="card card-hover p-3 stat-card">
      <div>
        <p class="text-muted mb-1">Reserved</p>
        <h3 class="mb-0"><?php echo $stats['reserved']; ?></h3>
      </div>
      <div class="stat-icon"><i class="bi bi-bookmark"></i></div>
    </div>
  </div>
  <div class="col-md-6 col-xl-2">
    <div class="card card-hover p-3 stat-card">
      <div>
        <p class="text-muted mb-1">Overdue</p>
        <h3 class="mb-0"><?php echo $overdueCount; ?></h3>
      </div>
      <div class="stat-icon" style="background: rgba(220, 38, 38, 0.15); color: var(--danger);"><i class="bi bi-exclamation-triangle"></i></div>
    </div>
  </div>
  <div class="col-md-6 col-xl-2">
    <div class="card card-hover p-3 stat-card">
      <div>
        <p class="text-muted mb-1">Total Users</p>
        <h3 class="mb-0"><?php echo $stats['users']; ?></h3>
      </div>
      <div class="stat-icon"><i class="bi bi-people"></i></div>
    </div>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-8">
    <div class="card p-4 h-100">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="section-title mb-0">Borrowing Snapshot</h5>
        <a class="btn btn-sm btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/full_report.php">Open Reports</a>
      </div>
      <canvas id="reportsChart" height="140" data-values="<?php echo $stats['borrowed']; ?>,<?php echo $stats['returned']; ?>,<?php echo $stats['reserved']; ?>"></canvas>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card p-4 h-100">
      <h5 class="section-title mb-3">Recent Borrows</h5>
      <?php if (!$recentBorrows) : ?>
        <p class="text-muted">No recent borrow activity.</p>
      <?php else : ?>
        <div class="d-grid gap-3">
          <?php foreach ($recentBorrows as $borrow) : ?>
            <?php 
              $isOverdue = $borrow['status'] === 'borrowed' && strtotime($borrow['due_at']) < time();
            ?>
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div class="fw-semibold"><?php echo htmlspecialchars($borrow['full_name']); ?></div>
                <div class="text-muted small"><?php echo htmlspecialchars($borrow['title']); ?></div>
              </div>
              <span class="badge badge-status <?php echo $isOverdue ? 'badge-overdue' : 'badge-borrowed'; ?>">
                <?php echo $isOverdue ? 'Overdue' : 'Due ' . date('M d', strtotime($borrow['due_at'])); ?>
              </span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="row g-3 mt-1">
  <div class="col-md-6 col-xl-3">
    <div class="card p-3 card-hover">
      <h6 class="fw-semibold mb-1">Borrow Report</h6>
      <p class="text-muted small">Filter by date, user, or book.</p>
      <a class="btn btn-sm btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/borrow_report.php">Open</a>
    </div>
  </div>
  <div class="col-md-6 col-xl-3">
    <div class="card p-3 card-hover">
      <h6 class="fw-semibold mb-1">Return Report</h6>
      <p class="text-muted small">Track completed returns.</p>
      <a class="btn btn-sm btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/return_report.php">Open</a>
    </div>
  </div>
  <div class="col-md-6 col-xl-3">
    <div class="card p-3 card-hover">
      <h6 class="fw-semibold mb-1">Reservation Report</h6>
      <p class="text-muted small">View current reservations.</p>
      <a class="btn btn-sm btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/reserve_report.php">Open</a>
    </div>
  </div>
  <div class="col-md-6 col-xl-3">
    <div class="card p-3 card-hover">
      <h6 class="fw-semibold mb-1">Full Report</h6>
      <p class="text-muted small">Combined borrowing activity.</p>
      <a class="btn btn-sm btn-outline-primary" href="<?php echo base_url(); ?>/admin/reports/full_report.php">Open</a>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
