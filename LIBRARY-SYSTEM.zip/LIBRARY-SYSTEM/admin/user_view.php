<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$page_title = 'User Dashboard Preview';
$is_admin = true;
$active_page = 'dashboard';

$books = db()->query('SELECT * FROM books ORDER BY created_at DESC LIMIT 8')->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <div>
    <p class="text-uppercase text-muted small mb-1">User Experience</p>
    <h1 class="section-title">User Dashboard Preview</h1>
  </div>
  <a class="btn btn-outline-primary" href="<?php echo base_url(); ?>/admin/dashboard.php">Back to Admin</a>
</div>

<div class="card p-4 mb-4">
  <h5 class="section-title">Welcome back, Reader!</h5>
  <p class="text-muted">Explore the latest titles and reserve your next read.</p>
</div>

<div class="row g-3" id="books">
  <?php foreach ($books as $book) : ?>
    <div class="col-md-6 col-xl-3">
      <div class="card p-3 h-100 card-hover">
        <h6 class="fw-semibold mb-1"><?php echo htmlspecialchars($book['title']); ?></h6>
        <p class="text-muted small mb-2"><?php echo htmlspecialchars($book['author']); ?></p>
        <div class="d-flex justify-content-between align-items-center mb-3">
          <span class="badge badge-status <?php echo $book['copies_available'] > 0 ? 'badge-returned' : 'badge-borrowed'; ?>">
            <?php echo $book['copies_available'] > 0 ? 'Available' : 'Borrowed'; ?>
          </span>
          <span class="text-muted small"><?php echo $book['copies_available']; ?> left</span>
        </div>
        <button class="btn btn-primary btn-sm" type="button" disabled>Borrow</button>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
