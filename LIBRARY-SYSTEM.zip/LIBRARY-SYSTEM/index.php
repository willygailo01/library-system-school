<?php
require_once __DIR__ . '/includes/session.php';

if (is_logged_in()) {
  if (is_admin()) {
    redirect('/admin/dashboard.php');
  }
  redirect('/user/dashboard.php');
}

redirect('/auth/login.php');
