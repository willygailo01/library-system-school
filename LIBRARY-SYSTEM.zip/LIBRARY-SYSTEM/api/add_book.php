<?php
require_once __DIR__ . '/../includes/session.php';

if (!is_logged_in() || !is_admin()) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 401);
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
  $payload = $_POST;
}

$token = $payload['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!verify_csrf($token)) {
  json_response(['status' => 'error', 'message' => 'Invalid CSRF token.'], 403);
}

$title = trim($payload['title'] ?? '');
$author = trim($payload['author'] ?? '');
$isbn = trim($payload['isbn'] ?? '');
$category = trim($payload['category'] ?? '');
$copies = (int)($payload['copies_total'] ?? 1);

if ($title === '' || $author === '' || $copies < 1) {
  json_response(['status' => 'error', 'message' => 'Missing required fields.'], 422);
}

$stmt = db()->prepare('INSERT INTO books (title, author, isbn, category, copies_total, copies_available) VALUES (?, ?, ?, ?, ?, ?)');
$stmt->execute([$title, $author, $isbn, $category, $copies, $copies]);

json_response(['status' => 'success', 'message' => 'Book added successfully.', 'reload' => true]);
