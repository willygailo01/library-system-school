<?php
require_once __DIR__ . '/../includes/session.php';

if (!is_logged_in()) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 401);
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
  $payload = $_POST;
}

$token = $payload['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!verify_csrf($token)) {
  json_response(['status' => 'error', 'message' => 'Invalid CSRF token.'], 403);
}

$borrow_id = (int)($payload['borrow_id'] ?? 0);
if ($borrow_id <= 0) {
  json_response(['status' => 'error', 'message' => 'Invalid request.'], 422);
}

$query = "SELECT id, book_id, user_id FROM borrows WHERE id = ? AND status = 'borrowed'";
$stmt = db()->prepare($query);
$stmt->execute([$borrow_id]);
$borrow = $stmt->fetch();
if (!$borrow) {
  json_response(['status' => 'error', 'message' => 'Borrow record not found.'], 404);
}

if (!is_admin() && (int)$borrow['user_id'] !== (int)($_SESSION['user']['id'] ?? 0)) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 403);
}

$update = db()->prepare("UPDATE borrows SET status = 'returned', returned_at = NOW() WHERE id = ?");
$update->execute([$borrow_id]);

$bookUpdate = db()->prepare('UPDATE books SET copies_available = copies_available + 1 WHERE id = ?');
$bookUpdate->execute([$borrow['book_id']]);

$reservations = db()->prepare("SELECT id FROM reservations WHERE book_id = ? AND status = 'active' ORDER BY reserved_at ASC LIMIT 1");
$reservations->execute([$borrow['book_id']]);
$nextReservation = $reservations->fetch();
if ($nextReservation) {
  $fulfill = db()->prepare("UPDATE reservations SET status = 'fulfilled', fulfilled_at = NOW() WHERE id = ?");
  $fulfill->execute([$nextReservation['id']]);
  
  $bookUpdate2 = db()->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ?');
  $bookUpdate2->execute([$borrow['book_id']]);
}

json_response(['status' => 'success', 'message' => 'Book returned successfully.', 'reload' => true]);
