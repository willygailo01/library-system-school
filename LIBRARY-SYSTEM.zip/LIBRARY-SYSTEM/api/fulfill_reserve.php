<?php
require_once __DIR__ . '/../includes/session.php';

if (!is_logged_in() || !is_admin()) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 401);
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
  $payload = $_POST;
}

$token = $payload['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!verify_csrf($token)) {
  json_response(['status' => 'error', 'message' => 'Invalid CSRF token.'], 403);
}

$reservation_id = (int)($payload['reservation_id'] ?? 0);
if ($reservation_id <= 0) {
  json_response(['status' => 'error', 'message' => 'Invalid reservation ID.'], 422);
}

$stmt = db()->prepare('SELECT * FROM reservations WHERE id = ? AND status = "active"');
$stmt->execute([$reservation_id]);
$reservation = $stmt->fetch();
if (!$reservation) {
  json_response(['status' => 'error', 'message' => 'Reservation not found or already processed.'], 404);
}

$bookStmt = db()->prepare('SELECT copies_available FROM books WHERE id = ?');
$bookStmt->execute([$reservation['book_id']]);
$book = $bookStmt->fetch();

if (!$book || (int)$book['copies_available'] <= 0) {
  json_response(['status' => 'error', 'message' => 'Book not available to fulfill reservation.'], 409);
}

$due = (new DateTime('+14 days'))->format('Y-m-d');
$borrow = db()->prepare('INSERT INTO borrows (user_id, book_id, due_at) VALUES (?, ?, ?)');
$borrow->execute([$reservation['user_id'], $reservation['book_id'], $due]);

$update = db()->prepare("UPDATE reservations SET status = 'fulfilled', fulfilled_at = NOW() WHERE id = ?");
$update->execute([$reservation_id]);

$bookUpdate = db()->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ?');
$bookUpdate->execute([$reservation['book_id']]);

json_response(['status' => 'success', 'message' => 'Reservation fulfilled and borrow created.', 'reload' => true]);
