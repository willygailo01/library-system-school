<?php
require_once __DIR__ . '/../includes/session.php';

if (!is_logged_in()) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 401);
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
  $payload = $_POST;
}

$token = $payload['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!verify_csrf($token)) {
  json_response(['status' => 'error', 'message' => 'Invalid CSRF token.'], 403);
}

$book_id = (int)($payload['book_id'] ?? 0);
$user_id = (int)($payload['user_id'] ?? 0);
if (!$user_id || !is_admin()) {
  $user_id = (int)($_SESSION['user']['id'] ?? 0);
}

if ($book_id <= 0 || $user_id <= 0) {
  json_response(['status' => 'error', 'message' => 'Invalid request.'], 422);
}

$activeBorrow = db()->prepare("SELECT id FROM borrows WHERE user_id = ? AND book_id = ? AND status = 'borrowed'");
$activeBorrow->execute([$user_id, $book_id]);
if ($activeBorrow->fetch()) {
  json_response(['status' => 'error', 'message' => 'You already have this book borrowed.'], 409);
}

$bookStmt = db()->prepare('SELECT copies_available FROM books WHERE id = ?');
$bookStmt->execute([$book_id]);
$book = $bookStmt->fetch();
if (!$book || (int)$book['copies_available'] <= 0) {
  json_response(['status' => 'error', 'message' => 'Book not available.'], 409);
}

$due = $payload['due_at'] ?? null;
if (!$due) {
  $due = (new DateTime('+14 days'))->format('Y-m-d');
}

$borrow = db()->prepare('INSERT INTO borrows (user_id, book_id, due_at) VALUES (?, ?, ?)');
$borrow->execute([$user_id, $book_id, $due]);

$update = db()->prepare('UPDATE books SET copies_available = copies_available - 1 WHERE id = ?');
$update->execute([$book_id]);

json_response(['status' => 'success', 'message' => 'Borrow recorded successfully.', 'reload' => true]);
