<?php
require_once __DIR__ . '/../includes/session.php';

if (!is_logged_in() || !is_admin()) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 401);
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
  $payload = $_POST;
}

$token = $payload['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!verify_csrf($token)) {
  json_response(['status' => 'error', 'message' => 'Invalid CSRF token.'], 403);
}

$id = (int)($payload['id'] ?? 0);
if ($id <= 0) {
  json_response(['status' => 'error', 'message' => 'Invalid book ID.'], 422);
}

$stmt = db()->prepare("SELECT COUNT(*) FROM borrows WHERE book_id = ? AND status = 'borrowed'");
$stmt->execute([$id]);
if ((int)$stmt->fetchColumn() > 0) {
  json_response(['status' => 'error', 'message' => 'Book has active borrows.'], 409);
}

$delete = db()->prepare('DELETE FROM books WHERE id = ?');
$delete->execute([$id]);

json_response(['status' => 'success', 'message' => 'Book deleted successfully.', 'reload' => true]);
