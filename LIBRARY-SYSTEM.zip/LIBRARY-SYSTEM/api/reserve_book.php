<?php
require_once __DIR__ . '/../includes/session.php';

if (!is_logged_in()) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 401);
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
  $payload = $_POST;
}

$token = $payload['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!verify_csrf($token)) {
  json_response(['status' => 'error', 'message' => 'Invalid CSRF token.'], 403);
}

$book_id = (int)($payload['book_id'] ?? 0);
$user_id = (int)($_SESSION['user']['id'] ?? 0);

if ($book_id <= 0 || $user_id <= 0) {
  json_response(['status' => 'error', 'message' => 'Invalid request.'], 422);
}

$bookStmt = db()->prepare('SELECT copies_available FROM books WHERE id = ?');
$bookStmt->execute([$book_id]);
$book = $bookStmt->fetch();
if (!$book) {
  json_response(['status' => 'error', 'message' => 'Book not found.'], 404);
}

$activeBorrow = db()->prepare("SELECT id FROM borrows WHERE user_id = ? AND book_id = ? AND status = 'borrowed'");
$activeBorrow->execute([$user_id, $book_id]);
if ($activeBorrow->fetch()) {
  json_response(['status' => 'error', 'message' => 'You already have this book borrowed.'], 409);
}

$exists = db()->prepare("SELECT id FROM reservations WHERE user_id = ? AND book_id = ? AND status = 'active'");
$exists->execute([$user_id, $book_id]);
if ($exists->fetch()) {
  json_response(['status' => 'error', 'message' => 'You already have an active reservation.'], 409);
}

$insert = db()->prepare('INSERT INTO reservations (user_id, book_id) VALUES (?, ?)');
$insert->execute([$user_id, $book_id]);

json_response(['status' => 'success', 'message' => 'Reservation placed successfully.', 'reload' => true]);
