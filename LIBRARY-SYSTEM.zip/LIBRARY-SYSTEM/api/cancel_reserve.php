<?php
require_once __DIR__ . '/../includes/session.php';

if (!is_logged_in()) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 401);
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
  $payload = $_POST;
}

$token = $payload['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
if (!verify_csrf($token)) {
  json_response(['status' => 'error', 'message' => 'Invalid CSRF token.'], 403);
}

$reservation_id = (int)($payload['reservation_id'] ?? 0);
if ($reservation_id <= 0) {
  json_response(['status' => 'error', 'message' => 'Invalid request.'], 422);
}

$stmt = db()->prepare('SELECT id, user_id FROM reservations WHERE id = ? AND status = "active"');
$stmt->execute([$reservation_id]);
$reservation = $stmt->fetch();
if (!$reservation) {
  json_response(['status' => 'error', 'message' => 'Reservation not found.'], 404);
}

if (!is_admin() && (int)$reservation['user_id'] !== (int)($_SESSION['user']['id'] ?? 0)) {
  json_response(['status' => 'error', 'message' => 'Unauthorized'], 403);
}

$update = db()->prepare("UPDATE reservations SET status = 'cancelled', cancelled_at = NOW() WHERE id = ?");
$update->execute([$reservation_id]);

json_response(['status' => 'success', 'message' => 'Reservation cancelled.', 'reload' => true]);
